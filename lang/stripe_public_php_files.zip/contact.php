<?php
require_once 'init.php';
$support_email = 'support@' . preg_replace('/^www\./','', $_SERVER['HTTP_HOST']);
?>
<!DOCTYPE html>
<html lang="<?php echo isset($lang) ? htmlspecialchars($lang) : 'lt'; ?>">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title><?php echo t('legal_contact_title'); ?></title>
  <link rel="stylesheet" href="style.css">
</head>
<body>
<?php if (file_exists('ui_topbar.php')) include 'ui_topbar.php'; ?>
<div class="container" style="max-width:900px;margin:0 auto;padding:16px;">
  <h1><?php echo t('legal_contact_title'); ?></h1>
  <p><?php echo str_replace('{support_email}', htmlspecialchars($support_email), t('legal_contact_p1')); ?></p>
  <p><?php echo t('legal_contact_p2'); ?></p>
</div>
</body>
</html>
